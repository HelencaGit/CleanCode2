
package es.ed.model;

/**
 *
 * @author Helen
 */
public class Ruedas {
    private String materialRuedas;
    private int numRuedas;

    public String getMaterialRuedas() {
        return materialRuedas;
    }

    public void setMaterialRuedas(String materialRuedas) {
        this.materialRuedas = materialRuedas;
    }

    public int getNumRuedas() {
        return numRuedas;
    }

    public void setNumRuedas(int numRuedas) {
        this.numRuedas = numRuedas;
    }
    
    
}
